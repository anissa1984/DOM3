
let line = document.querySelectorAll(".line")
console.log(line)

let prix = document.querySelectorAll(".prix")
console.log(prix)

let amount = document.querySelectorAll(".amount")
console.log(amount)

let diminution = document.querySelectorAll(".diminution")
console.log(diminution)

let ajout = document.querySelectorAll(".ajouter")
console.log(ajout)

let supp = document.querySelectorAll(".supprimer")
console.log(supp)

let total = document.querySelector(".Total")
console.log(total)

let quant = document.querySelectorAll(".quant")
console.log(quant)



for (let i = 0; i<ajout.length; i++){
  ajout [i].addEventListener("click", increment)

  function increment(){
    console.log("increment click")
    quant[i].value++
    totale()
  }
}

for (let i = 0; i<diminution.length; i++){
  diminution [i].addEventListener("click",decrement)

  function decrement(){
    console.log("decrement click")
    quant[i].value--
    totale()
  }
}

function totale(){
 

  let prixTotal = 0
  for(let i = 0; i < prix.length; i++){
    prixTotal += quant[i].value * parseInt(prix[i].innerHTML)
  }
  total.innerHTML = prixTotal + "Da"
}

// delete
for (let i = 0; i < supp.length; i++){
supp [i].addEventListener("click", supprimer)

  function supprimer(){
 quant[i].value = 0
  line [i].remove()
  totale()

  }


}







